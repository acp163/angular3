export interface Procedure {
    id:String;
    trxCorrelationId: String;
    appCode: String;
    appDescription: String;
    env: String;
    threadPath: String;
    hostname: String;
    stepDescription: String;
    stepType: String;
    thread: String;
    logTimeStamp: String;

}
