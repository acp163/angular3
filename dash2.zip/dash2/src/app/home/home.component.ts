import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { EMPTY, fromEvent, Observable, throwError } from 'rxjs';
import { catchError, debounceTime, filter, map, retry, switchMap } from 'rxjs/operators';
import { Procedure } from '../model/procedure';
import { CorreationService } from '../shared/correation.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements AfterViewInit {

  @ViewChild('correlationSearch') correlationField: ElementRef;
  title = 'AngularMaterialGettingStarted';
  searchResult$:Observable<String[]>;
  procedureList$: Observable<Procedure[]>;
  constructor(private correationService: CorreationService) {
    this.procedureList$ = correationService.getPrcedureList();
  }

  ngAfterViewInit() {

    let keyup$ = fromEvent(this.correlationField.nativeElement, 'keyup');
    this.searchResult$ = keyup$.pipe(debounceTime(500), map(event => event['target'].value),
    filter(search => !!search),
    switchMap(search => this.getSearchCorrelation(search))
    ).pipe( retry(4),catchError((error) => {
      console.error(`error while loading procedure description ${error}`);
       return EMPTY;
       }))
  }
  getSearchCorrelation(search:string):Observable<any> {
    return this.correationService.getSearchCorelation(search);
  }

}
