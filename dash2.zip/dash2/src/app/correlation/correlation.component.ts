import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { Procedure } from '../model/procedure';
import { CorreationService } from '../shared/correation.service';
import { catchError, filter, map, switchMap } from 'rxjs/operators';
import { of } from 'rxjs/internal/observable/of';
import { throwError } from 'rxjs/internal/observable/throwError';

@Component({
  selector: 'app-correlation',
  templateUrl: './correlation.component.html',
  styleUrls: ['./correlation.component.css']
})
export class CorrelationComponent implements OnInit {

  procedureList$: Observable<Procedure[]>
  procedure$: Observable<Procedure>;
  loddingError$ = new Subject<boolean>();


  isMenuOpen = true;
  contentMargin = 240;

  constructor(private route: ActivatedRoute, private correationService: CorreationService) {
    //this.procedureList$ = correationService.getPrcedureList();
    this.procedureList$ = this.route.paramMap.pipe(map(params => params.get('correlationId')),
      filter(correlationId => !!correlationId),
      switchMap(correlationId => this.correationService.getPrcedureViaCorrelation(correlationId))
    );
  }

  ngOnInit(): void {


  }

  stepDescriptionHandler(id) {

    this.procedure$ = this.correationService.getPrcedureViaId(id).pipe(
      catchError((error) => {
        console.error(`error while loading procedure description ${error}`);
        this.loddingError$.next(true);
        return throwError(error);
      })

    );



  }

}
