import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RightSideCorrelationComponent } from './right-side-correlation.component';

describe('RightSideCorrelationComponent', () => {
  let component: RightSideCorrelationComponent;
  let fixture: ComponentFixture<RightSideCorrelationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RightSideCorrelationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RightSideCorrelationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
