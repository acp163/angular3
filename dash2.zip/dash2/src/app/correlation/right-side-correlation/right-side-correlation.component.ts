import { Component, Input, OnInit } from '@angular/core';
import { Procedure } from 'src/app/model/procedure';

@Component({
  selector: 'app-right-side-correlation',
  templateUrl: './right-side-correlation.component.html',
  styleUrls: ['./right-side-correlation.component.css']
})
export class RightSideCorrelationComponent implements OnInit {

  @Input() procedure: Procedure;

  constructor() { }

  ngOnInit(): void {
  }
  }



