import { TestBed } from '@angular/core/testing';

import { CorreationService } from './correation.service';

describe('CorreationService', () => {
  let service: CorreationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CorreationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
