import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Procedure } from '../model/procedure';

@Injectable({
  providedIn: 'root'
})
export class CorreationService {

  constructor(private http: HttpClient) { }
  getPrcedureList(): Observable<Procedure[]> {
    return this.http.get<Procedure[]>('http://localhost:8080/api/v2/procedure');
  }
  getPrcedureViaCorrelation(correlationId): Observable<Procedure[]> {
    return this.http.get<Procedure[]>(`http://localhost:8080/api/v2/procedure/tr/${correlationId}`);
  }
  getPrcedureViaId(id: String): Observable<Procedure> {
    return this.http.get<Procedure>(`http://localhost:8080/api/v2/procedure/details/${id}`);
  }

  getSearchCorelation(correlationId): Observable<string[]> {
    return this.http.get<string[]>(`http://localhost:8080/api/v2/procedure/trx-Correlation/${correlationId}`);
  }
}
