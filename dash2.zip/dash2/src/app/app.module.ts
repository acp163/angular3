import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopNavComponent } from './top-nav/top-nav.component';
import { DashboardMaterialModule } from './dashboard-material/dashboard-material.module';
import { SideNavComponent } from './side-nav/side-nav.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { RightSideNavComponent } from './right-side-nav/right-side-nav.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { CorrelationComponent } from './correlation/correlation.component';
import { RightSideCorrelationComponent } from './correlation/right-side-correlation/right-side-correlation.component';

@NgModule({
  declarations: [
    AppComponent,
    TopNavComponent,
    SideNavComponent,
    RightSideNavComponent,
    HomeComponent,
    CorrelationComponent,
    RightSideCorrelationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DashboardMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
